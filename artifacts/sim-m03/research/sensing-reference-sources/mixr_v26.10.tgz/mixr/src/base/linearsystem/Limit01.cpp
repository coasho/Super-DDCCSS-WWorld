
#include "mixr/base/linearsystem/Limit01.hpp"
#include <iostream>

namespace mixr {
namespace base {

IMPLEMENT_SUBCLASS(Limit01, "Limit01")
EMPTY_SLOTTABLE(Limit01)
EMPTY_COPYDATA(Limit01)
EMPTY_DELETEDATA(Limit01)

Limit01::Limit01() : ILimitFunc(0,1)
{
   STANDARD_CONSTRUCTOR()
}

}
}
